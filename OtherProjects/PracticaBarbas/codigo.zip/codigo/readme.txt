Para ejecutar el programa con CLIPS:

  1 - cd al directorio 'codigo'

  2 - ejecutar el siguiente comando:

      clips -f run.bat

      De esta forma cargamos el fichero .clp, y hacemos (reset) + (run)
